﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InicioCartas
{
    public partial class Form1 : Form
    {

        int espaçoCartas = 0;
        public Form1()
        {
            InitializeComponent();
        }



        private void deck_Click(object sender, EventArgs e)
        {
            espaçoCartas++;

            Button Carta = new Button();
            Carta.Location = new Point(140* espaçoCartas/2, 234);
            Carta.Size = new Size(78,100);
            Carta.Click += DynamicButton_Click;
            Carta.MouseEnter += Escolhendoimagem_MouseEnter;

            Controls.Add(Carta);

        }

        private void DynamicButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("AHHHHHHHHHHHHHH");
        }

        private void Escolhendoimagem_MouseEnter(object sender, EventArgs e)
        {
            
        }
    }
}
